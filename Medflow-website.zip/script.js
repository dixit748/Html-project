const text = ['Medflow'];
let index = 0;
let charIndex = 0;
let currentText = '';
let isDeleting = false;
const typingElement = document.querySelector('.typing');
function type() {
if(index < text.length){
if(!isDeleting && charIndex <= text[index].length){
currentText = text[index].substring(0,charIndex);
typingElement.textContent = currentText;
charIndex++;
setTimeout(type,200);
}
else if(isDeleting && charIndex >= 0){
currentText = text[index].substring(0,charIndex);
typingElement.textContent = currentText;
charIndex--;
setTimeout(type,100);
}
else {
isDeleting = !isDeleting;
setTimeout(type,1000);
}
}
}
type();